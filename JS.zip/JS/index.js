/*  const input= prompt('wie alt bist du?');
console.log(input);
console.log(typeof input);
const age= parseInt(input);
console.log(typeof age);
alert(age);  */




/* 

let a= 5;
let b= 3;
let c= 2;

let greater= b > a;
console.log(greater);
console.log('a === b', a === b);

console.log('a + b=', a + b);
console.log('a - b=', a - b);
console.log('a * b=', a * b);
console.log('a / b=', a / b);
console.log('a % b=', a % b);  */





/*  const victimDead = true;
const treacherous = true;
const cruel = false;
const baseMotives = false;

const isMurder= victimDead && (treacherous || cruel || baseMotives);
Manslaughter= victimDead && !(treacherous || cruel || baseMotives);
console.log(isMurder);
console.log(Manslaughter);  */





/*  document.getElementById('headline').innerHTML = 'Hello world';  */	//Etwas in HTML ansprechen




/*  window.alert('REEEEEEEEEEE');  */	// Alert: Popt ein Fenster beim laden der Seite auf.




/*  var hans = 5, peter = 12;		// Var steht für variation also wie das x bei Mathe, kann man irgend welche sachen irgend welche werte geben
window.alert(hans % peter);  */			// Hier findet eine Rechnung statt: + = plus rechnen. - = Minus rechnen, / = Durch rechnen, * = Mal rechnen




/*  var txt = 'Dings\tBums';
window.alert(txt.split(''));  */




/*  var bool = Boolean(42 >= 42);			// == Überprüft ob es gleich ist. === Überprüft auch noch den Typ </> Größer oder kleiner. </>= Überprüft ob es kleiner/größer gleicht. != Überprüft ob sie verschieden sind.
window.alert(bool);  */




/*if (24 > 1337) {							// "Wenn 1337 größer als 24 ist(true), dann window alert"
	window.alert('REEEEEEEE');
}  
else {										// "Wenn false, dann anderes window alert"
	window.alert('RATATATATATA')
}*/





/*switch (new Date().getDate()) {
case 0:
	window.alert('Montag');
	break;
case 1:
	window.alert('Dienstag');
	break;
case 2:
	window.alert('Mittwoch');
	break;
case 3:
	window.alert('Donnerstag');
	break;
case 4:
	window.alert('Freitag');
	break;
case 5:
	window.alert('Samstag');
	break;
case 6:
	window.alert('Sonntag');
	break;
}*/

/*$(document).on('mouseover', '.hov .column', function(){
	$(this).addClass('active')
})*/




/* var layer1 = document.getElementById('layer1');
scroll = window.pageYOffset;
document.addEventListener('scroll', function (e) {
	var offset = window.pageYOffset;
	scroll = offset;
	layer1.style.width = (100 + scroll/5) + '%';
});*/